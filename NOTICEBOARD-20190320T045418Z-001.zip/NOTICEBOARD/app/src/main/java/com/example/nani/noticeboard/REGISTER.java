package com.example.nani.noticeboard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class REGISTER extends AppCompatActivity {

    EditText e1,e2,e3,e4;
    Button b1;
    Mydb my;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        e1=(EditText)findViewById(R.id.editText);
        e2=(EditText)findViewById(R.id.editText4);
        e3=(EditText)findViewById(R.id.editText2);
        e4=(EditText)findViewById(R.id.editText3);
        b1=(Button)findViewById(R.id.button);
        my=new Mydb(this);
    }
    public void reg(View view) {
        if (e1.getText().toString().trim().length() == 0) {
            e1.setError("name is not entered");
            e1.requestFocus();
        }
        if (e2.getText().toString().trim().length() == 0) {
            e2.setError("regno is not entered");
            e2.requestFocus();
        }
        if (e3.getText().toString().trim().length() == 0) {
            e3.setError("password is not entered");
            e3.requestFocus();
        }
        if (e4.getText().toString().trim().length() == 0) {
            e4.setError("phone is not entered");
            e4.requestFocus();
        } else {
            Intent i2 = new Intent(this, MainActivity.class);
            startActivity(i2);


            String name = e1.getText().toString();
            String uid = e2.getText().toString();
            String pwd = e3.getText().toString();
            String phn = e4.getText().toString();


            long a = my.insertdata(name, uid, pwd, phn);

            if (a > 0) {
                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(this, LOGIN.class);
                startActivity(i);
            } else {
                Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
            }

        }
    }
    public void display(View view) {


        my.display();
    }

}
