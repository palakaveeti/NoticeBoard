package com.example.nani.noticeboard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LOGIN extends AppCompatActivity {
    EditText e1;
    EditText e2;
    Button b1;
    Mydb my;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e1=(EditText)findViewById(R.id.editText5);
        e2=(EditText)findViewById(R.id.editText6);
        b1=(Button)findViewById(R.id.b1);
        my=new Mydb(this);
    }
    public void log(View view) {
        String uid=e1.getText().toString();
        String pwd=e2.getText().toString();
        String admin_uid=new String("admin");
        String admin_pwd=new String("123");
        if(uid.equals(admin_uid) & pwd.equals(admin_pwd)){
            Intent i=new Intent(this,admin.class);
            startActivity(i);
        }
        else if(my.select(uid,pwd)==2){
            Intent i= new Intent(this,NoticeBoard.class);
            startActivity(i);
        }
        else{
            Intent i= new Intent(this,LOGIN.class);
            startActivity(i);
            Toast.makeText(this, "login falied", Toast.LENGTH_SHORT).show();
        }

    }

}
