package com.example.nani.noticeboard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class admin extends AppCompatActivity {
    EditText add;
    Mydb my;
    Button addb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        add = (EditText) findViewById(R.id.add);
        addb = (Button) findViewById(R.id.addb);
        my = new Mydb(this);

    }


    public void logout(View view) {
        Intent ilo = new Intent(this, LOGIN.class);
        startActivity(ilo);
    }

    public void add(View view) {
        if (add.getText().toString().trim().length() == 0) {
            add.setError(" not entered");
            add.requestFocus();
        } else {
            Intent i2 = new Intent(this, admin.class);
            startActivity(i2);

            String nid = add.getText().toString();
            String notice = add.getText().toString();


            long a = my.insertdata1(nid,notice);
            if (a > 0) {
                Toast.makeText(this, " successful", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(this, admin.class);

                startActivity(i);
            } else {
                Toast.makeText(this, " failed", Toast.LENGTH_SHORT).show();
            }


        }
    }

    public void view(View view) {
        my.display2();
    }
}

