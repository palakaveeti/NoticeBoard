package com.example.nani.noticeboard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

/**
 * Created by DELL on 11-03-2018.
 */

public class Mydb extends SQLiteOpenHelper {
    SQLiteDatabase readable,writable;
    Context ct;
    public Mydb(Context context) {
        super(context, "user", null, 1);
        this.ct=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query="create table data(name text,uid int,pwd text,phn int);";
        db.execSQL(query);
        String querys="create table datan(nid int,notice text);";
        db.execSQL(querys);



    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists data");
        sqLiteDatabase.execSQL("drop table if exists datan");
    }

    public long insertdata(String name, String uid, String pwd, String phn) {
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("uid", uid);
        values.put("pwd", pwd);
        values.put("phn", phn);
        writable = getWritableDatabase();
        return writable.insert("data", null, values);


    }
    public long insertdata1(String nid,String notice) {
        ContentValues values = new ContentValues();
        values.put("nid", nid);
        values.put("notice", notice);
        writable = getWritableDatabase();
        return writable.insert("datan", null, values);
    }

    public void display() {
        readable=getReadableDatabase();
        Cursor c=readable.query("data",new String[]{"name","uid","pwd","phn"},null,null,null,null,null);
        //Cursor c=readable.query("data",new String[]{"name","uid","pwd","phn"},"uid=? and pwd=?",new String[]{"values['uid']","values['pwd']"},null,null,null);
        while(c.moveToNext())
        {
            String name=c.getString(0);
            String uid=c.getString(1);
            String pwd=c.getString(2);
            String phn=c.getString(3);
            Toast.makeText(ct,""+name+""+uid+""+pwd+""+phn+"\n", Toast.LENGTH_SHORT).show();
        }
    }
    public void display2() {
        readable=getReadableDatabase();
        Cursor c=readable.query("datan",new String[]{"notice"},null,null,null,null,null);
        //Cursor c=readable.query("data",new String[]{"name","uid","pwd","phn"},"uid=? and pwd=?",new String[]{"values['uid']","values['pwd']"},null,null,null);
        while(c.moveToNext())
        {
            String notice=c.getString(0);

            Toast.makeText(ct,""+notice+"\n", Toast.LENGTH_SHORT).show();
        }
    }


    public int select(String uid, String pwd) {
        readable = getReadableDatabase();
        Cursor c=readable.query("data",new String[]{"name","uid","pwd","phn"},"uid=? and pwd=?",new String[]{uid,pwd},null,null,null);
        while(c.moveToNext()){
            return 2;
        }
        return 3;
    }
}
