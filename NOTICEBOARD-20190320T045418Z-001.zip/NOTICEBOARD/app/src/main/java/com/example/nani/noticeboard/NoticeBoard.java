package com.example.nani.noticeboard;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NoticeBoard extends AppCompatActivity {
Button view;
    Mydb my;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_board);
        my = new Mydb(this);
    }

    public void VIEW(View view) {

        my.display2();

    }
}
